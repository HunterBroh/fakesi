window.drawThumbnail = function (canv) {
    canv.width = window.innerWidth;
    canv.height = window.innerHeight;

    const ctx = canv.getContext('2d');
    const image = new Image();

    image.onload = function () {
        const scale = Math.max(
            canv.width / image.width,
            canv.height / image.height
        );

        const imageWidth = image.width * scale;
        const imageHeight = image.height * scale;

        const x = (canv.width - imageWidth) / 2;
        const y = (canv.height - imageHeight) / 2;

        ctx.clearRect(0, 0, canv.width, canv.height);

        // Fuzzy/blurred image
        ctx.filter = 'blur(4px)';
        ctx.drawImage(image, x, y, imageWidth, imageHeight);

        // Reset the canvas filter
        ctx.filter = 'none';
    };

    image.onerror = function () {
        console.error('Could not load thumbnail.png');
    };

    image.src = './thumbnail.png';
};
